# 发布前需要确定的许可证

项目所有者已于 2026-09-15 确认采用 MIT 许可证，版权署名为 `sxlforget2-cyber`。正式授权文本见 [LICENSE](LICENSE)，允许在遵守许可证要求的前提下使用、修改、再分发和商用。本文件仅保留授权决策说明。

选择前曾考虑的产品路线（以下不是额外限制）：

- 公开源码并采用 MIT 等宽松许可证：适合允许他人修改和商用的开源项目。
- 公开源码并采用 GPL 等附带再分发义务的许可证：需要先理解其适用条件。
- 暂时不公开源码：使用私有开发仓库，另以公开分发仓库发布应用包、使用说明及适用的最终用户条款。

不能把“允许别人下载应用”“公开源代码”“允许商用和再分发”当作同一个决定。GitHub 说明：[为仓库选择许可证](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository)。
