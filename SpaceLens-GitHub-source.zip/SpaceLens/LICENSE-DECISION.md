# 发布前需要确定的许可证

项目所有者尚未选择开源许可证。本文件不是开源许可证，也不授予新的使用、再分发或商用授权。发布前由所有者确定授权方案，并在适用时添加正式 LICENSE。

可选择的产品路线：

- 公开源码并采用 MIT 等宽松许可证：适合允许他人修改和商用的开源项目。
- 公开源码并采用 GPL 等附带再分发义务的许可证：需要先理解其适用条件。
- 暂时不公开源码：使用私有开发仓库，另以公开分发仓库发布应用包、使用说明及适用的最终用户条款。

不能把“允许别人下载应用”“公开源代码”“允许商用和再分发”当作同一个决定。GitHub 说明：[为仓库选择许可证](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository)。
