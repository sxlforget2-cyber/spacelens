// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "SpaceLens",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "SpaceLens", targets: ["SpaceLens"])],
    targets: [
        .target(name: "ScanCore"),
        .executableTarget(name: "SpaceLens", dependencies: ["ScanCore"]),
        .executableTarget(name: "ScanCoreChecks", dependencies: ["ScanCore"])
    ]
)
