# GitHub 发布手册

## 当前状态

这是发布准备包，不代表软件已经在 GitHub 上线。仓库、源码公开范围及许可证由项目所有者确定。普通用户的正式下载包还需要 Apple Developer ID 签名、公证，以及完整界面和多机验收。

## 一、先建立仓库

建议仓库名 `spacelens`。尚未确定源码授权时，可先创建私有仓库。把本目录中的文件放在仓库根目录；`.github` 是自动检查和反馈模板所在的隐藏目录，也需要上传。

不要把整个工作目录上传。构建缓存、扫描清单、证书、私钥和开发者凭据均不应上传。`scripts/package-source.sh` 使用明确的文件白名单生成可上传源码包。

仓库说明建议：`A local-first, read-only macOS file inspection tool for AI coding workflows.`

首次上传后在 Actions 中检查自动编译结果。它只有仓库读取权限，不使用签名密钥，不发布 Release，也不运行来自 PR 的高权限发布任务。当前工作流为配置就绪状态，尚未在远程 GitHub 执行。

## 二、准备预览版

```sh
bash scripts/prepare-release.sh preview
bash scripts/package-source.sh
```

输出位于 `dist/`。预览包按实际构建机器架构命名，带 `-preview` 后缀和 SHA-256 文件；它只有本地临时签名，尚未经过 Apple 公证。适合明确理解这些限制的开发测试，不应包装成普通用户可顺畅安装的正式版本。不要指导用户关闭 Gatekeeper。

## 三、完成正式签名和公证

1. 项目所有者本人注册 Apple Developer Program 个人账号，完成身份验证、协议和付款。
2. 在本机配置 Developer ID Application 证书及私钥，并准备可用的 Xcode 公证工具。用 `security find-identity -v -p codesigning` 查看证书名称。
3. 通过 Apple 的 `notarytool store-credentials` 交互流程把公证凭据存入本机钥匙串。不要把密码或证书粘贴到仓库、Issue 或聊天中。
4. 设置非密码的配置值，执行正式打包。以下证书名称是格式示例，必须替换为自己的真实证书名称；钥匙串配置名必须与本机已保存的名称一致。

```sh
export SPACELENS_SIGN_IDENTITY='Developer ID Application: YOUR LEGAL NAME (TEAMID)'
export SPACELENS_NOTARY_PROFILE='spacelens-notary'
bash scripts/prepare-release.sh release
```

脚本会编译、运行扫描检查、使用 Hardened Runtime 签名、提交公证、检查 Accepted 状态、附加及验证公证凭据、执行 Gatekeeper 评估，最后才生成正式 ZIP 和校验文件。缺少配置、公证拒绝或验证失败会中止，不会静默改用临时签名生成正式包。

现有同名输出不会覆盖。中间产物保留在被 Git 忽略的 `.release-work/`，方便检查失败原因。可通过 `SPACELENS_BUILD_DIR` 指定已有构建缓存。

## 四、发布前实际验收

- 在另一台 Mac 上从下载链接获取压缩包，正常解压、打开。
- 使用脱敏测试目录完成选择目录、扫描、分类筛选、勾选、取消和 JSON 导出。
- 确认拒绝权限时有清晰提示，扫描自身的 CPU／内存占用可接受。
- 覆盖支持的 macOS 版本；只声明实际验证过的架构，不把 arm64 包描述成 Intel 通用包。
- 核对源码授权、隐私说明、已知限制和反馈入口。
- 核对清单里的内容未被宣传成“已确认可以安全删除”，候选体积未被宣传成保证释放空间。

## 五、GitHub Releases

验收后，进入仓库 Releases → Draft a new release。选择对应源码提交，建立与实际版本一致的标签；先保存 Draft，测试阶段勾选 Pre-release。上传应用 ZIP 与对应 `.sha256` 文件，而不是把二进制提交进源码目录。

当前版本可使用 `v0.1.0-preview.1` 标识预览发布；等正式版具备签名、公证及验收记录后再发布 `v0.1.0`。如果修改软件，必须重新构建、签名、公证和计算校验值，不能复用旧包的通过结果。

可用于预览 Release 的说明：

> SpaceLens 空间透镜 0.1.0 开发预览。用于检查重复文件、大文件、长期未修改文件和开发产物，扫描在本机进行，由用户决定如何处理。
>
> 本版不删除文件，不关闭进程，不保证候选体积等于实际可释放空间。macOS 13+，请核对下载文件标注的架构。
>
> `-preview` 安装包未进行 Developer ID 签名和 Apple 公证；完整界面流程及多机兼容性尚待验收。请勿用于无人值守清理。
>
> 反馈时请使用虚构文件名和脱敏截图，不要上传完整扫描报告。

## 官方参考

- [GitHub Releases](https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases)
- [Apple 个人开发者注册](https://developer.apple.com/cn/help/account/membership/enrolling-in-the-app)
- [Apple 公证流程](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution)
