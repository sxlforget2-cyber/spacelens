import Foundation
import CryptoKit
import Darwin

public enum Category: String, CaseIterable, Codable {
    case duplicates = "重复文件", large = "大文件", old = "长期未修改", generated = "开发产物"
    public var symbol: String {
        switch self {
        case .duplicates: return "doc.on.doc"
        case .large: return "externaldrive"
        case .old: return "clock"
        case .generated: return "hammer"
        }
    }
}

public struct Finding: Identifiable, Codable {
    public var id: String { path }
    public let path: String
    public let category: Category
    public let bytes: Int64
    public let modified: Date
    public let reason: String
    public let relatedPaths: [String]
    public var name: String { URL(fileURLWithPath: path).lastPathComponent }

    public init(path: String, category: Category, bytes: Int64, modified: Date, reason: String, relatedPaths: [String] = []) {
        self.path = path; self.category = category; self.bytes = bytes
        self.modified = modified; self.reason = reason; self.relatedPaths = relatedPaths
    }
}

public struct ScanReport: Codable {
    public let root: String
    public let date: Date
    public var scannedFiles = 0
    public var scannedBytes: Int64 = 0
    public var skipped = 0
    public var findings: [Finding] = []
    public var notes: [String] = []
    public var cancelled = false
    public var candidateBytes: Int64 { findings.reduce(0) { $0 + $1.bytes } }
    public init(root: String, date: Date = Date()) { self.root = root; self.date = date }
}

public struct ScanOptions {
    public var largeBytes: Int64 = 100 * 1024 * 1024
    public var oldBytes: Int64 = 10 * 1024 * 1024
    public var oldDays = 180
    public var duplicateMinimum: Int64 = 1024 * 1024
    public var maxHashFileBytes: Int64 = 2 * 1024 * 1024 * 1024
    public var maxHashBytes: Int64 = 20 * 1024 * 1024 * 1024
    public var maxEntries = 150_000
    public init() {}
}

public final class CancellationToken: @unchecked Sendable {
    private let lock = NSLock()
    private var flag = false
    public init() {}
    public func cancel() { lock.lock(); flag = true; lock.unlock() }
    public var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return flag }
}

private struct Record {
    let url: URL
    let size: Int64
    let modified: Date
    let identity: String
    let stamp: stat
}

public enum Scanner {
    // These trees contain credentials, application state, cloud data, or system files.
    // Users can select a specific permitted cache folder instead of scanning Library wholesale.
    private static let protectedNames: Set<String> = [
        ".git", ".ssh", ".aws", ".gnupg", ".codex", ".claude", ".Trash",
        "Library", "System", "Applications", "Backups.backupdb", ".Spotlight-V100", ".fseventsd"
    ]
    private static let generatedNames: Set<String> = ["node_modules", ".build", ".next", "__pycache__", ".pytest_cache"]
    private static let bundleExtensions: Set<String> = ["app", "photoslibrary", "photolibrary", "bundle", "framework", "backupbundle", "sparsebundle"]

    public static func scan(root: URL, options: ScanOptions = ScanOptions(), token: CancellationToken = CancellationToken(), progress: @escaping (String) -> Void = { _ in }) -> ScanReport {
        let fm = FileManager.default
        let base = canonicalRoot(root)
        var report = ScanReport(root: base.path)
        var rootStat = stat()
        guard lstat(base.path, &rootStat) == 0, rootStat.st_mode & S_IFMT == S_IFDIR else {
            report.notes = ["所选目录无法读取，请检查路径与访问权限。"]
            return report
        }
        guard base.path != "/", !protectedNames.contains(base.lastPathComponent),
              !bundleExtensions.contains(base.pathExtension.lowercased()),
              !base.pathComponents.contains(where: { [".ssh", ".aws", ".gnupg", ".codex", ".claude", ".git", "System"].contains($0) }) else {
            report.notes = ["此目录属于默认保护范围。请选择下载、文档或某个项目目录。"]
            return report
        }
        let keys: Set<URLResourceKey> = [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey, .isPackageKey, .isUbiquitousItemKey, .ubiquitousItemDownloadingStatusKey]
        var errors = 0
        guard let enumerator = fm.enumerator(at: base, includingPropertiesForKeys: Array(keys), options: [], errorHandler: { _, _ in errors += 1; return true }) else {
            report.notes = ["目录无法访问，扫描未完成。"]
            return report
        }
        var records: [Record] = []
        var identities = Set<String>()
        var generated: [String: (size: Int64, date: Date)] = [:]
        var currentGenerated: String? = generatedNames.contains(base.lastPathComponent) ? base.path : nil
        var entries = 0
        var hitLimit = false
        while let url = enumerator.nextObject() as? URL {
            if token.isCancelled { break }
            entries += 1
            if entries > options.maxEntries { hitLimit = true; break }
            if entries % 250 == 0 { progress("正在索引 · 已检查 \(entries) 个项目") }
            do {
                let v = try url.resourceValues(forKeys: keys)
                var info = stat()
                guard lstat(url.path, &info) == 0 else { report.skipped += 1; enumerator.skipDescendants(); continue }
                let kind = info.st_mode & S_IFMT
                // Skip symlinks, other mounted devices, and dataless File Provider placeholders.
                if kind == S_IFLNK || info.st_dev != rootStat.st_dev || (info.st_flags & UInt32(SF_DATALESS)) != 0 ||
                    (v.isUbiquitousItem == true && v.ubiquitousItemDownloadingStatus == .notDownloaded) {
                    enumerator.skipDescendants(); report.skipped += 1; continue
                }
                if let parent = currentGenerated, !url.path.hasPrefix(parent + "/") { currentGenerated = nil }
                if kind == S_IFDIR {
                    if protectedNames.contains(url.lastPathComponent) || v.isPackage == true || bundleExtensions.contains(url.pathExtension.lowercased()) {
                        enumerator.skipDescendants(); report.skipped += 1; continue
                    }
                    if currentGenerated == nil && generatedNames.contains(url.lastPathComponent) { currentGenerated = url.path }
                    continue
                }
                guard kind == S_IFREG else { report.skipped += 1; continue }
                let identity = "\(info.st_dev):\(info.st_ino)"
                // A second hard link is not a second independent copy.
                guard identities.insert(identity).inserted else { report.skipped += 1; continue }
                let size = Int64(info.st_size)
                let date = Date(timeIntervalSince1970: TimeInterval(info.st_mtimespec.tv_sec))
                report.scannedFiles += 1
                report.scannedBytes += size
                if let parent = currentGenerated {
                    let previous = generated[parent]
                    generated[parent] = ((previous?.size ?? 0) + size, max(previous?.date ?? .distantPast, date))
                } else {
                    records.append(Record(url: url, size: size, modified: date, identity: identity, stamp: info))
                }
            } catch { report.skipped += 1; enumerator.skipDescendants() }
        }
        report.skipped += errors
        var duplicates = Set<String>()
        var retained = Set<String>()
        var hashBytes: Int64 = 0
        var hashLimited = false
        var hashFailures = 0
        let sizeGroups = Dictionary(grouping: records.filter { $0.size >= options.duplicateMinimum }, by: \.size)
        for size in sizeGroups.keys.sorted() {
            if token.isCancelled { break }
            guard let group = sizeGroups[size], group.count > 1 else { continue }
            if size > options.maxHashFileBytes { hashLimited = true; continue }
            var digestGroups: [String: [Record]] = [:]
            for record in group.sorted(by: { $0.url.path < $1.url.path }) {
                if token.isCancelled { break }
                guard hashBytes + size <= options.maxHashBytes else { hashLimited = true; continue }
                hashBytes += size
                progress("正在比对内容 · \(record.url.lastPathComponent)")
                if let digest = digest(record, token: token) { digestGroups[digest, default: []].append(record) }
                else if !token.isCancelled { hashFailures += 1 }
            }
            for matches in digestGroups.values where matches.count > 1 {
                // Revalidate all file metadata after hashing; live writes can invalidate a match.
                let stable = matches.filter { record in
                    var now = stat()
                    return lstat(record.url.path, &now) == 0 && sameSnapshot(record.stamp, now)
                }.sorted { $0.url.path < $1.url.path }
                guard let original = stable.first, stable.count > 1 else { continue }
                retained.insert(original.url.path)
                for record in stable.dropFirst() {
                    duplicates.insert(record.url.path)
                    report.findings.append(Finding(path: record.url.path, category: .duplicates, bytes: record.size, modified: record.modified,
                        reason: "SHA-256 内容一致。参照副本按路径排序选取，保留位置仍需你判断；不同路径可能被不同项目引用。",
                        relatedPaths: [original.url.path]))
                }
            }
        }
        let cutoff = Date().addingTimeInterval(-Double(options.oldDays) * 86400)
        for record in records where !duplicates.contains(record.url.path) && !retained.contains(record.url.path) {
            if record.modified < cutoff && record.size >= options.oldBytes {
                report.findings.append(Finding(path: record.url.path, category: .old, bytes: record.size, modified: record.modified,
                    reason: "超过 \(options.oldDays) 天未修改且体积较大。修改时间不代表最近使用时间，请先确认用途。"))
            } else if record.size >= options.largeBytes {
                report.findings.append(Finding(path: record.url.path, category: .large, bytes: record.size, modified: record.modified,
                    reason: "文件达到大文件阈值。大小只是筛选条件，请确认是否仍需保留。"))
            }
        }
        for (path, data) in generated where data.size > 0 {
            report.findings.append(Finding(path: path, category: .generated, bytes: data.size, modified: data.date,
                reason: "按目录名称识别的依赖或构建产物，未验证可重建性与运行占用。删除可能中断项目，下次运行可能需要重新下载或构建。"))
        }
        report.findings.sort { $0.bytes == $1.bytes ? $0.path < $1.path : $0.bytes > $1.bytes }
        report.cancelled = token.isCancelled
        report.notes.append("只读扫描；各分类互斥。体积为文件逻辑大小，不是保证可释放空间；APFS 克隆、压缩和快照会影响实际回收。")
        report.notes.append("默认跳过系统目录、应用包、部分敏感目录、符号链接、其他挂载设备及识别到的云端占位文件。隐藏文件仅用于本地扫描。")
        report.notes.append("重复检测只检查同大小且至少 \(formatBytes(options.duplicateMinimum)) 的文件；开发产物内部不单独比对。")
        if report.skipped > 0 { report.notes.append("跳过 \(report.skipped) 个文件或目录，包括保护项、硬链接别名或无法读取的项目；不代表全盘扫描。") }
        if hitLimit { report.notes.append("达到 \(options.maxEntries) 项扫描上限，结果仅覆盖已扫描部分；开发目录体积也可能不完整。请缩小扫描目录。") }
        if hashLimited { report.notes.append("部分内容比对达到资源上限：单文件最多 \(formatBytes(options.maxHashFileBytes))，合计最多 \(formatBytes(options.maxHashBytes))。重复结果不完整。") }
        if hashFailures > 0 { report.notes.append("\(hashFailures) 个文件因变化或读取失败未完成内容比对。") }
        if report.cancelled { report.notes.append("扫描已取消，当前仅为部分结果；开发目录体积可能不完整。") }
        progress(report.cancelled ? "已取消 · 部分结果" : "扫描完成")
        return report
    }

    private static func canonicalRoot(_ url: URL) -> URL {
        // Foundation can abbreviate /private/var to /var while enumeration returns
        // /private/var. POSIX realpath keeps root and enumerated paths consistent.
        guard let path = realpath(url.path, nil) else { return url.standardizedFileURL }
        defer { free(path) }
        return URL(fileURLWithPath: String(cString: path), isDirectory: true)
    }

    private static func sameSnapshot(_ a: stat, _ b: stat) -> Bool {
        a.st_dev == b.st_dev && a.st_ino == b.st_ino && a.st_size == b.st_size &&
        a.st_mtimespec.tv_sec == b.st_mtimespec.tv_sec && a.st_mtimespec.tv_nsec == b.st_mtimespec.tv_nsec &&
        a.st_ctimespec.tv_sec == b.st_ctimespec.tv_sec && a.st_ctimespec.tv_nsec == b.st_ctimespec.tv_nsec &&
        (b.st_mode & S_IFMT) == S_IFREG
    }

    private static func digest(_ record: Record, token: CancellationToken) -> String? {
        let fd = open(record.url.path, O_RDONLY | O_NOFOLLOW | O_NONBLOCK)
        guard fd >= 0 else { return nil }
        defer { close(fd) }
        var before = stat()
        guard fstat(fd, &before) == 0, sameSnapshot(record.stamp, before), before.st_flags & UInt32(SF_DATALESS) == 0 else { return nil }
        var hasher = SHA256()
        var buffer = [UInt8](repeating: 0, count: 1024 * 1024)
        var count: Int64 = 0
        while !token.isCancelled {
            let n = read(fd, &buffer, buffer.count)
            if n < 0 { if errno == EINTR { continue }; return nil }
            if n == 0 { break }
            count += Int64(n)
            guard count <= record.size else { return nil }
            hasher.update(data: Data(buffer[0..<n]))
        }
        var after = stat()
        guard !token.isCancelled, count == record.size, fstat(fd, &after) == 0, sameSnapshot(before, after) else { return nil }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}

public func formatBytes(_ value: Int64) -> String {
    value == 0 ? "0 B" : ByteCountFormatter.string(fromByteCount: value, countStyle: .file)
}
