import Foundation
import ScanCore

// Standalone regression runner; works with Command Line Tools without full Xcode/XCTest.
let fm = FileManager.default
if let index = CommandLine.arguments.firstIndex(of: "--fixture"), CommandLine.arguments.count > index + 1 {
    let target = URL(fileURLWithPath: CommandLine.arguments[index + 1])
    guard !fm.fileExists(atPath: target.path) else { fatalError("Fixture target must not already exist") }
    try fm.createDirectory(at: target.appendingPathComponent("project/node_modules"), withIntermediateDirectories: true)
    let data = Data(repeating: 65, count: 2 * 1024 * 1024)
    try data.write(to: target.appendingPathComponent("素材原件.bin"))
    try data.write(to: target.appendingPathComponent("素材副本.bin"))
    try data.write(to: target.appendingPathComponent("project/node_modules/test.bin"))
    let old = target.appendingPathComponent("旧版归档.bin")
    try Data(repeating: 66, count: 12 * 1024 * 1024).write(to: old)
    try fm.setAttributes([.modificationDate: Date().addingTimeInterval(-200 * 86400)], ofItemAtPath: old.path)
    print("Created isolated UI fixture: \(target.path)")
    exit(0)
}
let fixture = fm.temporaryDirectory.resolvingSymlinksInPath().appendingPathComponent("SpaceLensChecks-" + UUID().uuidString)
try fm.createDirectory(at: fixture, withIntermediateDirectories: true)
defer { try? fm.removeItem(at: fixture) }
var passed = 0
func check(_ condition: @autoclosure () -> Bool, _ name: String) {
    guard condition() else {
        fputs("FAIL: \(name)\n", stderr)
        try? fm.removeItem(at: fixture)
        exit(1)
    }
    passed += 1
    print("PASS: \(name)")
}
func folder(_ name: String) throws -> URL {
    let url = fixture.appendingPathComponent(name)
    try fm.createDirectory(at: url, withIntermediateDirectories: true)
    return url
}
@discardableResult
func file(_ root: URL, _ name: String, _ text: String) throws -> URL {
    let url = root.appendingPathComponent(name)
    try fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
    try Data(text.utf8).write(to: url)
    return url
}
var options = ScanOptions()
options.duplicateMinimum = 1
options.largeBytes = 1
options.oldBytes = 1

let duplicates = try folder("duplicates")
let a = try file(duplicates, "a.txt", "same-content")
try file(duplicates, "b.txt", "same-content")
try file(duplicates, "c.txt", "else-content")
let before = try Data(contentsOf: a)
let r = Scanner.scan(root: duplicates, options: options)
check(r.findings.filter { $0.category == .duplicates }.count == 1, "same content only; same size with different bytes excluded")
let canonicalA = a.standardizedFileURL.resolvingSymlinksInPath().path
let referencePaths = r.findings.first { $0.category == .duplicates }?.relatedPaths.map { URL(fileURLWithPath: $0).resolvingSymlinksInPath().path }
check(referencePaths == [canonicalA], "duplicate has explicit reference copy")
check(!r.findings.contains { URL(fileURLWithPath: $0.path).resolvingSymlinksInPath().path == canonicalA }, "reference copy not offered in another category")
check(Set(r.findings.map(\.path)).count == r.findings.count, "categories do not overlap")
let after = try Data(contentsOf: a)
check(before == after && (try? fm.contentsOfDirectory(atPath: duplicates.path).count) == 3, "scan preserves file content and directory entries")

let links = try folder("links")
let original = try file(links, "a.txt", "hardlinked")
try fm.linkItem(at: original, to: links.appendingPathComponent("b.txt"))
try fm.createSymbolicLink(at: links.appendingPathComponent("outside"), withDestinationURL: duplicates)
let lr = Scanner.scan(root: links, options: options)
check(lr.scannedFiles == 1 && !lr.findings.contains { $0.category == .duplicates }, "hard links counted once; directory symlinks not traversed")

let dev = try folder("dev")
try file(dev, "node_modules/one/index.js", "12345678")
try file(dev, "node_modules/one/node_modules/two/index.js", "12345678")
try file(dev, ".git/objects/secret", "private")
try file(dev, ".ssh/key", "private")
try file(dev, "Example.app/Contents/MacOS/run", "package")
try file(dev, "notes.txt", "ok")
let dr = Scanner.scan(root: dev, options: options)
check(dr.scannedFiles == 3, "protected directories and app bundles skipped")
check(dr.findings.filter { $0.category == .generated }.count == 1 && dr.findings.first { $0.category == .generated }?.bytes == 16, "nested dependencies aggregate without overlap")
let direct = Scanner.scan(root: dev.appendingPathComponent("node_modules"), options: options)
check(direct.findings.count == 1 && direct.findings[0].category == .generated, "direct dependency folder selection works")
let blocked = Scanner.scan(root: dev.appendingPathComponent(".git"), options: options)
check(blocked.scannedFiles == 0 && !blocked.notes.isEmpty, "sensitive root blocked explicitly")

let old = try folder("old")
let archived = try file(old, "archive.zip", "older-file")
try fm.setAttributes([.modificationDate: Date().addingTimeInterval(-200 * 86400)], ofItemAtPath: archived.path)
let or = Scanner.scan(root: old, options: options)
check(or.findings.first?.category == .old && or.findings.first!.reason.contains("不代表"), "old modification date labeled as evidence, not non-use")

var limited = options
limited.maxEntries = 1
let limit = Scanner.scan(root: duplicates, options: limited)
check(limit.scannedFiles == 1 && limit.notes.contains { $0.contains("扫描上限") }, "metadata cap surfaces incomplete coverage")
limited = options; limited.maxHashBytes = 0
let hashLimit = Scanner.scan(root: duplicates, options: limited)
check(!hashLimit.findings.contains { $0.category == .duplicates } && hashLimit.notes.contains { $0.contains("资源上限") }, "hash cap does not invent duplicates")
let token = CancellationToken(); token.cancel()
let cancelled = Scanner.scan(root: duplicates, options: options, token: token)
check(cancelled.cancelled && cancelled.scannedFiles == 0, "cancellation returns labeled partial results")
let missing = Scanner.scan(root: fixture.appendingPathComponent("missing"))
check(missing.scannedFiles == 0 && !missing.notes.isEmpty, "missing directory produces explanation")

let changing = try folder("changing")
let changingA = try file(changing, "a.txt", "same-content")
try file(changing, "b.txt", "same-content")
var changed = false
let changeResult = Scanner.scan(root: changing, options: options) { status in
    if status.contains("比对"), !changed {
        try? Data("different-size-content".utf8).write(to: changingA)
        changed = true
    }
}
check(!changeResult.findings.contains { $0.category == .duplicates }, "file changes after enumeration invalidate duplicate match")
let encoded = try JSONEncoder().encode(r)
let decoded = try JSONDecoder().decode(ScanReport.self, from: encoded)
check(decoded.findings.count == r.findings.count && decoded.root == r.root, "report JSON round trip")
print("\n\(passed) checks passed. All scan fixtures were isolated temporary files.")
