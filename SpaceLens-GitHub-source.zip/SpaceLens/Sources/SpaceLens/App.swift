import SwiftUI
import AppKit
import UniformTypeIdentifiers
import ScanCore
import Darwin

@main
enum EntryPoint {
    static func main() {
        if let index = CommandLine.arguments.firstIndex(of: "--scan"), CommandLine.arguments.count > index + 1 {
            let report = Scanner.scan(root: URL(fileURLWithPath: CommandLine.arguments[index + 1]))
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            encoder.dateEncodingStrategy = .iso8601
            if let data = try? encoder.encode(report) { FileHandle.standardOutput.write(data) }
            return
        }
        SpaceLensApp.main()
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

struct SpaceLensApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup("SpaceLens · 空间透镜") {
            ContentView(model: model)
                .frame(minWidth: 1080, minHeight: 710)
                .preferredColorScheme(.light)
        }
        .defaultSize(width: 1240, height: 820)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("选择扫描目录…") { model.chooseFolder() }.keyboardShortcut("o")
            }
        }
    }
}

private let ink = Color(red: 0.10, green: 0.19, blue: 0.18)
private let accent = Color(red: 0.13, green: 0.44, blue: 0.34)
private let canvas = Color(red: 0.96, green: 0.97, blue: 0.95)

@MainActor
final class AppModel: ObservableObject {
    @Published var report = AppModel.demoReport()
    @Published var isDemo = true
    @Published var scanning = false
    @Published var status = "先浏览示例，再选择你想检查的目录"
    @Published var filter: ScanCore.Category?
    @Published var query = ""
    @Published var selection = Set<String>()
    @Published var focused: String?
    @Published var diskFree: Int64 = 0
    @Published var diskTotal: Int64 = 0
    @Published var swap: Int64?
    @Published var error: String?
    private var token: CancellationToken?
    private var runID = UUID()
    private var lastProgress = Date.distantPast

    init() { focused = report.findings.first?.id; refreshSystem() }
    var visible: [Finding] {
        report.findings.filter { (filter == nil || $0.category == filter) && (query.isEmpty || $0.path.localizedCaseInsensitiveContains(query)) }
    }
    var detail: Finding? { report.findings.first { $0.id == focused } }
    var selectedBytes: Int64 { report.findings.filter { selection.contains($0.id) }.reduce(0) { $0 + $1.bytes } }

    func refreshSystem() {
        let path = isDemo ? NSHomeDirectory() : report.root
        if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: path) {
            diskFree = (attrs[.systemFreeSize] as? NSNumber)?.int64Value ?? 0
            diskTotal = (attrs[.systemSize] as? NSNumber)?.int64Value ?? 0
        }
        var usage = xsw_usage()
        var size = MemoryLayout<xsw_usage>.size
        swap = sysctlbyname("vm.swapusage", &usage, &size, nil, 0) == 0 ? Int64(usage.xsu_used) : nil
    }

    func chooseFolder() {
        guard !scanning else { return }
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true; panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.prompt = "只读扫描"
        panel.message = "选择下载、文档或项目目录。扫描结果只在本机处理。"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        start(url)
    }

    func start(_ url: URL) {
        guard !scanning else { return }
        let scoped = url.startAccessingSecurityScopedResource()
        let cancellation = CancellationToken()
        let id = UUID()
        runID = id; token = cancellation
        isDemo = false; scanning = true; selection.removeAll(); focused = nil
        filter = nil; query = ""; status = "开始索引目录…"
        report = ScanReport(root: url.path)
        refreshSystem()
        Task {
            let result = await Task.detached(priority: .utility) {
                Scanner.scan(root: url, token: cancellation) { message in
                    Task { @MainActor [weak self] in
                        guard let self, self.runID == id, self.scanning,
                              Date().timeIntervalSince(self.lastProgress) > 0.15 else { return }
                        self.lastProgress = Date(); self.status = message
                    }
                }
            }.value
            if scoped { url.stopAccessingSecurityScopedResource() }
            guard runID == id else { return }
            report = result; scanning = false; token = nil
            focused = result.findings.first?.id
            status = result.cancelled ? "扫描已取消 · 当前为部分结果" : "扫描完成 · 已检查 \(result.scannedFiles) 个文件"
            refreshSystem()
        }
    }

    func cancel() { token?.cancel(); status = "正在结束扫描…" }
    func toggle(_ item: Finding) {
        if selection.contains(item.id) { selection.remove(item.id) } else { selection.insert(item.id) }
    }
    func reveal(_ path: String) {
        guard !isDemo else { return }
        guard FileManager.default.fileExists(atPath: path) else { error = "文件已移动或不存在，请重新扫描。"; return }
        NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
    }
    func activityMonitor() {
        NSWorkspace.shared.open(URL(fileURLWithPath: "/System/Applications/Utilities/Activity Monitor.app"))
    }
    func export() {
        struct Export: Encodable {
            let version = "0.1"
            let demo: Bool
            let selectedPaths: [String]
            let report: ScanReport
            let notice = "只读建议清单。勾选不代表文件可安全删除，逻辑大小不等于实际可释放空间。"
        }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.json]
        panel.nameFieldStringValue = "SpaceLens-清理建议.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            encoder.dateEncodingStrategy = .iso8601
            try encoder.encode(Export(demo: isDemo, selectedPaths: selection.sorted(), report: report)).write(to: url, options: .atomic)
            status = "建议清单已导出 · 含扫描路径及勾选状态"
        } catch { self.error = "导出失败：\(error.localizedDescription)" }
    }

    static func demoReport() -> ScanReport {
        var r = ScanReport(root: "示例数据 · 未扫描你的文件")
        r.scannedFiles = 2486; r.scannedBytes = 18_600_000_000
        let now = Date()
        r.findings = [
            Finding(path: "/示例/Projects/website/node_modules", category: .generated, bytes: 1_820_000_000, modified: now.addingTimeInterval(-86400 * 12), reason: "按目录名称识别的项目依赖。下次启动可能需要重新下载；请先确认项目未运行且依赖可重建。"),
            Finding(path: "/示例/Downloads/设计素材-副本.zip", category: .duplicates, bytes: 864_000_000, modified: now.addingTimeInterval(-86400 * 25), reason: "示例：文件内容完全相同。请比较保存位置与用途，再决定保留哪一份。", relatedPaths: ["/示例/Documents/设计素材.zip"]),
            Finding(path: "/示例/Downloads/产品演示.mov", category: .large, bytes: 628_000_000, modified: now.addingTimeInterval(-86400 * 9), reason: "超过 100 MiB 的大文件，可确认是否已归档或仍需编辑。"),
            Finding(path: "/示例/Documents/旧版方案.zip", category: .old, bytes: 246_000_000, modified: now.addingTimeInterval(-86400 * 218), reason: "超过 180 天未修改。修改时间不代表最近使用时间，请确认是否仍需保留。"),
            Finding(path: "/示例/Projects/mac-tool/.build", category: .generated, bytes: 184_000_000, modified: now.addingTimeInterval(-86400 * 4), reason: "构建产物可能可以重建，但尚未验证。正在构建时不适合清理。")
        ]
        r.notes = ["当前文件列表是演示数据；右上方硬盘与内存信息来自本机实时读取。", "实际扫描按内容验证重复；长期未修改仅作为参考。", "候选体积为逻辑大小。APFS 克隆、压缩、快照等会影响实际释放空间。"]
        return r
    }
}

struct ContentView: View {
    @ObservedObject var model: AppModel
    var body: some View {
        HStack(spacing: 0) {
            sidebar.frame(width: 190)
            Divider()
            VStack(alignment: .leading, spacing: 20) {
                header
                metrics
                if model.isDemo {
                    Label("体验模式 · 下方为示例文件，选择目录后显示真实结果", systemImage: "sparkles")
                        .font(.system(size: 12, weight: .medium)).foregroundStyle(accent)
                        .padding(12).frame(maxWidth: .infinity, alignment: .leading)
                        .background(accent.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
                }
                results
                footer
            }.padding(26).background(canvas)
        }
        .foregroundStyle(ink).tint(accent)
        .onChange(of: model.filter) { _ in model.focused = model.visible.first?.id }
        .onChange(of: model.query) { _ in model.focused = model.visible.first?.id }
        .alert("提示", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
            Button("知道了") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 24) {
            HStack(spacing: 10) {
                Image(systemName: "viewfinder.circle.fill").font(.system(size: 30)).foregroundStyle(accent)
                VStack(alignment: .leading, spacing: 3) {
                    Text("SpaceLens").font(.system(size: 18, weight: .bold))
                    Text("空间透镜").font(.system(size: 11)).foregroundStyle(.secondary)
                }
            }.padding(.top, 16)
            VStack(alignment: .leading, spacing: 7) {
                Text("文件检查").font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary).padding(.bottom, 6)
                navigation("全部建议", symbol: "square.grid.2x2", category: nil)
                ForEach(ScanCore.Category.allCases, id: \.self) { c in navigation(c.rawValue, symbol: c.symbol, category: c) }
            }
            Spacer()
            VStack(alignment: .leading, spacing: 10) {
                Label("在本机完成", systemImage: "lock.shield").font(.system(size: 12, weight: .semibold))
                Text("扫描和内容比对均在本机处理。由你选择目录、查看依据、决定保留。").font(.system(size: 11)).foregroundStyle(.secondary).lineSpacing(4)
            }.padding(13).background(accent.opacity(0.06), in: RoundedRectangle(cornerRadius: 12))
            Text("MAC PREVIEW  /  0.1").font(.system(size: 9, weight: .medium, design: .monospaced)).foregroundStyle(.secondary)
        }.padding(18).background(Color.white)
    }

    private func navigation(_ title: String, symbol: String, category: ScanCore.Category?) -> some View {
        Button { model.filter = category } label: {
            HStack(spacing: 10) {
                Image(systemName: symbol).frame(width: 17)
                Text(title)
                Spacer()
                Text("\(model.report.findings.filter { category == nil || $0.category == category }.count)")
                    .font(.system(size: 10, design: .monospaced))
            }.font(.system(size: 12, weight: model.filter == category ? .semibold : .regular))
                .padding(.horizontal, 10).padding(.vertical, 11)
                .foregroundStyle(model.filter == category ? accent : ink.opacity(0.7))
                .background(model.filter == category ? accent.opacity(0.09) : .clear, in: RoundedRectangle(cornerRadius: 8))
        }.buttonStyle(.plain)
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 7) {
                Text("给电脑，留一点余地。").font(.system(size: 27, weight: .semibold))
                Text("看清文件占用，让每一次清理都有依据。")
                    .font(.system(size: 12)).foregroundStyle(.secondary)
            }
            Spacer()
            if model.scanning {
                Button("停止扫描") { model.cancel() }.controlSize(.large)
            } else {
                Button { model.chooseFolder() } label: { Label("选择目录扫描", systemImage: "folder.badge.plus") }
                    .buttonStyle(.borderedProminent).controlSize(.large)
            }
        }
    }

    private var metrics: some View {
        HStack(alignment: .top, spacing: 12) {
            metric(title: "待检查文件体积", value: formatBytes(model.report.candidateBytes), symbol: "square.stack.3d.up") {
                Text("\(model.report.findings.count) 条建议 · 非保证可释放空间")
            }
            metric(title: "所选磁盘可用 · 本机", value: formatBytes(model.diskFree), symbol: "internaldrive") {
                Text("磁盘总容量 \(formatBytes(model.diskTotal))")
            }
            metric(title: "物理内存 · 本机", value: ByteCountFormatter.string(fromByteCount: Int64(ProcessInfo.processInfo.physicalMemory), countStyle: .memory), symbol: "memorychip") {
                HStack(spacing: 5) {
                    Text("Swap \(model.swap.map { formatBytes($0) } ?? "未知")")
                    Button { model.activityMonitor() } label: { Image(systemName: "arrow.up.right.square") }.buttonStyle(.plain).help("打开活动监视器，查看内存压力")
                    Button { model.refreshSystem() } label: { Image(systemName: "arrow.clockwise") }.buttonStyle(.plain).help("刷新本机状态")
                }
            }
        }
    }

    private func metric<Detail: View>(title: String, value: String, symbol: String, @ViewBuilder detail: () -> Detail) -> some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack { Text(title); Spacer(); Image(systemName: symbol).foregroundStyle(accent) }.font(.system(size: 11)).foregroundStyle(.secondary)
            Text(value).font(.system(size: 28, weight: .semibold, design: .rounded))
            detail().font(.system(size: 10)).foregroundStyle(.secondary)
        }.padding(17).frame(maxWidth: .infinity, alignment: .leading).background(.white, in: RoundedRectangle(cornerRadius: 14))
    }

    private var results: some View {
        VStack(spacing: 0) {
            HStack {
                Text(model.filter?.rawValue ?? "全部建议").font(.system(size: 15, weight: .semibold))
                Text("\(model.visible.count)").font(.system(size: 11)).foregroundStyle(.secondary)
                Spacer()
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("搜索文件或路径", text: $model.query).textFieldStyle(.plain).frame(width: 155)
            }.padding(16)
            Divider()
            HStack(spacing: 0) {
                VStack(spacing: 0) {
                    HStack {
                        Text("勾选仅加入待处理清单"); Spacer(); Text("按体积排序 ↓")
                    }.font(.system(size: 10)).foregroundStyle(.secondary).padding(.horizontal, 16).padding(.vertical, 11)
                    if model.scanning {
                        Spacer(); ProgressView().controlSize(.small)
                        Text(model.status).font(.system(size: 12)).lineLimit(2).padding()
                        Text("流式比对，可随时停止").font(.system(size: 11)).foregroundStyle(.secondary); Spacer()
                    } else if model.visible.isEmpty {
                        Spacer(); Image(systemName: "checkmark.seal").font(.system(size: 32)).foregroundStyle(accent)
                        Text(model.query.isEmpty ? "当前范围没有候选项" : "没有匹配的文件").font(.system(size: 14)).padding(8)
                        Text("可更换目录；扫描范围与限制见下方说明。").font(.system(size: 11)).foregroundStyle(.secondary); Spacer()
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 0) {
                                ForEach(model.visible) { item in row(item) }
                            }
                        }
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                Divider()
                detailPanel.frame(width: 255)
            }.frame(minHeight: 235, maxHeight: .infinity)
            Divider()
            HStack {
                Image(systemName: "checkmark.circle").foregroundStyle(accent)
                Text("已勾选 \(model.selection.count) 项").font(.system(size: 11))
                Text(formatBytes(model.selectedBytes)).font(.system(size: 12, weight: .semibold))
                Spacer()
                Button("清空勾选") { model.selection.removeAll() }.buttonStyle(.plain).font(.system(size: 11)).disabled(model.selection.isEmpty)
                Button("导出建议清单…") { model.export() }.disabled(model.scanning)
            }.padding(14)
        }.background(.white, in: RoundedRectangle(cornerRadius: 14))
            .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func row(_ item: Finding) -> some View {
        HStack(spacing: 11) {
            Toggle("加入清单", isOn: Binding(get: { model.selection.contains(item.id) }, set: { _ in model.toggle(item) }))
                .labelsHidden().toggleStyle(.checkbox)
            Button { model.focused = item.id } label: {
                HStack(spacing: 11) {
                    Image(systemName: item.category.symbol).font(.system(size: 18)).foregroundStyle(accent)
                        .frame(width: 36, height: 40).background(canvas, in: RoundedRectangle(cornerRadius: 8))
                    VStack(alignment: .leading, spacing: 5) {
                        Text(item.name).font(.system(size: 12, weight: .medium)).lineLimit(1).truncationMode(.middle)
                        Text(item.category.rawValue + " · " + URL(fileURLWithPath: item.path).deletingLastPathComponent().path)
                            .font(.system(size: 10)).foregroundStyle(.secondary).lineLimit(1).truncationMode(.middle)
                    }
                    Spacer(minLength: 4)
                    Text(formatBytes(item.bytes)).font(.system(size: 12, weight: .medium, design: .rounded))
                }.contentShape(Rectangle())
            }.buttonStyle(.plain)
        }.padding(.horizontal, 15).padding(.vertical, 13)
            .background(model.focused == item.id ? accent.opacity(0.05) : .clear)
    }

    private var detailPanel: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("判断依据").font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
                if let item = model.detail {
                    Label(item.category.rawValue, systemImage: item.category.symbol).font(.system(size: 15, weight: .semibold)).foregroundStyle(accent)
                    Text(item.name).font(.system(size: 14, weight: .semibold)).textSelection(.enabled)
                    Text(item.reason).font(.system(size: 12)).lineSpacing(5)
                    Divider()
                    Text("完整路径").font(.system(size: 10)).foregroundStyle(.secondary)
                    Text(item.path).font(.system(size: 10, design: .monospaced)).textSelection(.enabled).lineSpacing(3)
                    Text("修改于 " + item.modified.formatted(date: .abbreviated, time: .omitted))
                        .font(.system(size: 10)).foregroundStyle(.secondary)
                    ForEach(item.relatedPaths, id: \.self) { path in
                        Text("参照副本（未计入候选体积）").font(.system(size: 10)).foregroundStyle(.secondary)
                        Text(path).font(.system(size: 10, design: .monospaced)).textSelection(.enabled)
                        Button("在 Finder 中查看参照副本") { model.reveal(path) }.disabled(model.isDemo)
                    }
                    Button { model.reveal(item.path) } label: { Label("在 Finder 中查看", systemImage: "folder") }.disabled(model.isDemo)
                    Text("原型只生成建议。确认后可在 Finder 中手动处理文件。").font(.system(size: 10)).foregroundStyle(.secondary).lineSpacing(3)
                } else {
                    Text("选择一条建议，查看文件信息和判断依据。").font(.system(size: 12)).foregroundStyle(.secondary)
                }
            }.frame(maxWidth: .infinity, alignment: .leading).padding(18)
        }.background(canvas.opacity(0.6))
    }

    private var footer: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Circle().fill(model.scanning ? Color.orange : accent).frame(width: 6, height: 6)
                Text(model.status).lineLimit(1)
                Spacer()
                Text("只读模式").foregroundStyle(accent)
            }.font(.system(size: 10))
            Text(model.report.root).font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1).truncationMode(.middle)
            DisclosureGroup("扫描说明与限制") {
                ScrollView {
                    VStack(alignment: .leading, spacing: 5) {
                        ForEach(model.report.notes, id: \.self) { Text($0).frame(maxWidth: .infinity, alignment: .leading) }
                    }
                }.frame(maxHeight: 95)
            }.font(.system(size: 10)).foregroundStyle(.secondary)
            Text("磁盘清理能腾出存储空间；运行内存不足仍需结合内存压力、并行任务和进程占用判断。")
                .font(.system(size: 10)).foregroundStyle(.secondary)
        }
    }
}
