#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
build_dir="${1:-$project_dir/.build}"
app_path="$project_dir/../SpaceLens.app"
swift build --package-path "$project_dir" --scratch-path "$build_dir" -c release --product SpaceLens
mkdir -p "$app_path/Contents/MacOS"
cp "$build_dir/release/SpaceLens" "$app_path/Contents/MacOS/SpaceLens"
cp "$project_dir/Info.plist" "$app_path/Contents/Info.plist"
codesign --force --sign - "$app_path"
printf 'Built: %s\n' "$app_path"
