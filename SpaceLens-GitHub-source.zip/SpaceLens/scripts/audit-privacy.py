#!/usr/bin/env python3
"""Inspect trusted release ZIPs without extraction. Does not upload any data.

Usage: python3 scripts/audit-privacy.py archive.zip --term PRIVATE_VALUE
Supply private terms locally; never commit them or the raw matching contents.
This checks known strings and home paths, not every possible personal identifier.
"""
import argparse
import getpass
import re
import sys
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("archive")
parser.add_argument("--term", action="append", default=[])
args = parser.parse_args()
terms = [t for t in args.term + [getpass.getuser()] if len(t) >= 3]
patterns = [re.compile(rb"/Users/[A-Za-z0-9_.-]+/"),
            re.compile(rb"[A-Za-z]:\\Users\\[A-Za-z0-9_.-]+\\")]
issues = []

def inspect(label, data):
    folded = data.lower()
    for term in terms:
        if any(term.lower().encode(enc) in folded for enc in ("utf-8", "utf-16-le", "utf-16-be")):
            issues.append((label, "private term found"))
            break
    if any(p.search(data) for p in patterns):
        issues.append((label, "absolute home path found"))

with zipfile.ZipFile(args.archive) as archive:
    inspect("archive comment", archive.comment)
    for entry in archive.infolist():
        inspect("entry name", entry.filename.encode())
        inspect(entry.filename + " metadata", entry.comment + entry.extra)
        if entry.filename.startswith("/") or ".." in entry.filename.split("/"):
            issues.append(("entry name", "unsafe archive path"))
        if "__MACOSX" in entry.filename or entry.filename.endswith(".DS_Store"):
            issues.append((entry.filename, "unnecessary macOS metadata"))
        if not entry.is_dir():
            if entry.file_size > 64 * 1024 * 1024:
                issues.append((entry.filename, "too large for this audit; manual review required"))
                continue
            inspect(entry.filename, archive.read(entry))
if issues:
    # Do not echo file names or matched values: they may themselves be private.
    for index, (_, reason) in enumerate(issues, 1):
        print(f"FAIL item {index}: {reason}")
    sys.exit(1)
print("PASS: ZIP contents, entry names, comments and extra fields; no configured private terms or home paths found.")
print("Limit: no anonymity guarantee; review Git history, profile and signing certificate separately.")
