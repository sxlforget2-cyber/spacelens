#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
destination="${1:-$project_dir/dist}"
mkdir -p "$destination" "$project_dir/.release-work"
destination="$(cd "$destination" && pwd)"
archive="$destination/SpaceLens-GitHub-source.zip"
if [[ -e "$archive" ]]; then printf '输出已存在：%s\n' "$archive" >&2; exit 73; fi
staging="$(mktemp -d "$project_dir/.release-work/source.XXXXXX")"
mkdir -p "$staging/SpaceLens"
# Explicit allowlist: build caches, test reports, signing material and .git are excluded.
for entry in Package.swift Info.plist build-app.sh README.md PRIVACY.md RELEASE.md TESTING.md LICENSE-DECISION.md CHANGELOG.md .gitignore .gitattributes .github Sources scripts; do
  ditto "$project_dir/$entry" "$staging/SpaceLens/$entry"
done
(
  cd "$staging"
  COPYFILE_DISABLE=1 /usr/bin/zip -X -q -r source.zip SpaceLens -x '*/.DS_Store' '*/._*'
)
python3 "$project_dir/scripts/audit-privacy.py" "$staging/source.zip"
cp -n "$staging/source.zip" "$archive"
printf 'Created: %s\n' "$archive"
