#!/bin/bash
# Local-only packager: never publishes a GitHub release or stores credentials.
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
mode="${1:-preview}"
destination="${2:-$project_dir/dist}"
build_dir="${SPACELENS_BUILD_DIR:-$project_dir/.build}"

case "$mode" in
  preview) ;;
  release)
    if [[ "${SPACELENS_ALLOW_IDENTITY_DISCLOSURE:-}" != yes ]]; then
      printf '%s\n' '正式签名证书可能公开个人姓名。确认接受后设置 SPACELENS_ALLOW_IDENTITY_DISCLOSURE=yes；当前未签名或提交公证。' >&2
      exit 78
    fi
    if [[ "${SPACELENS_SIGN_IDENTITY:-}" != "Developer ID Application: "* || -z "${SPACELENS_NOTARY_PROFILE:-}" ]]; then
      printf '%s\n' '正式包需要 SPACELENS_SIGN_IDENTITY（Developer ID Application 证书名称）和 SPACELENS_NOTARY_PROFILE（本机钥匙串配置名）。未生成正式包。' >&2
      exit 78
    fi
    xcrun --find notarytool >/dev/null
    xcrun --find stapler >/dev/null
    ;;
  *) printf 'Usage: bash scripts/prepare-release.sh preview|release [output-directory]\n' >&2; exit 64 ;;
esac

mkdir -p "$destination" "$project_dir/.release-work"
destination="$(cd "$destination" && pwd)"
version="$(/usr/libexec/PlistBuddy -c 'Print CFBundleShortVersionString' "$project_dir/Info.plist")"
architecture="$(uname -m)"
suffix=""
if [[ "$mode" == preview ]]; then suffix="-preview"; fi
filename="SpaceLens-$version-$architecture$suffix.zip"
archive="$destination/$filename"
if [[ -e "$archive" || -e "$archive.sha256" ]]; then
  printf '输出已存在，请使用新的输出目录：%s\n' "$archive" >&2
  exit 73
fi

privacy_flags=(-Xswiftc -file-prefix-map -Xswiftc "$project_dir=/SpaceLens"
  -Xswiftc -debug-prefix-map -Xswiftc "$build_dir=/build"
  -Xswiftc -file-compilation-dir -Xswiftc /SpaceLens)
swift build --package-path "$project_dir" --scratch-path "$build_dir" -c release "${privacy_flags[@]}"
bin_dir="$(swift build --package-path "$project_dir" --scratch-path "$build_dir" -c release --show-bin-path)"
"$bin_dir/ScanCoreChecks"
staging="$(mktemp -d "$project_dir/.release-work/package.XXXXXX")"
app="$staging/SpaceLens.app"
mkdir -p "$app/Contents/MacOS"
cp "$bin_dir/SpaceLens" "$app/Contents/MacOS/SpaceLens"
strip -S "$app/Contents/MacOS/SpaceLens"
cp "$project_dir/Info.plist" "$app/Contents/Info.plist"
plutil -lint "$app/Contents/Info.plist"

if [[ "$mode" == release ]]; then
  codesign --force --options runtime --timestamp --sign "$SPACELENS_SIGN_IDENTITY" "$app"
  codesign --verify --strict --verbose=2 "$app"
  ditto -c -k --sequesterRsrc --keepParent "$app" "$staging/notarization.zip"
  xcrun notarytool submit "$staging/notarization.zip" --keychain-profile "$SPACELENS_NOTARY_PROFILE" --wait --output-format json > "$staging/notary-result.json"
  verdict="$(plutil -extract status raw -o - "$staging/notary-result.json")"
  if [[ "$verdict" != Accepted ]]; then
    printf '公证未通过，未生成正式发布包。状态：%s；诊断结果：%s\n' "$verdict" "$staging/notary-result.json" >&2
    exit 1
  fi
  xcrun stapler staple "$app"
  xcrun stapler validate "$app"
  codesign --verify --strict --verbose=2 "$app"
  spctl --assess --type execute --verbose=2 "$app"
else
  codesign --force --options runtime --sign - "$app"
  codesign --verify --strict --verbose=2 "$app"
fi

# Exclude Finder metadata, resource forks, extended attributes and ZIP UID/GID fields.
# zip paths must be relative to staging (never include the developer's home path).
(
  cd "$staging"
  COPYFILE_DISABLE=1 /usr/bin/zip -X -q -r final-app.zip SpaceLens.app
)
python3 "$project_dir/scripts/audit-privacy.py" "$staging/final-app.zip"
# Publish the local output only after all required verification succeeds.
cp -n "$staging/final-app.zip" "$archive"
(
  cd "$destination"
  shasum -a 256 "$filename" > "$filename.sha256"
)
printf 'Created: %s\nSHA-256: %s.sha256\n' "$archive" "$archive"
if [[ "$mode" == preview ]]; then
  printf '%s\n' '仅供开发预览：本地临时签名，未公证，不是面向普通用户的正式安装包。'
fi
